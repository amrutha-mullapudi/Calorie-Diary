package com.example.burn;


import android.widget.ImageView;

public class example_item {
    private String strng;
    private int image1;
    public example_item(int imagev, String str1){
        strng=str1;
        image1 = imagev;
    }
    public String stringresource(){
        return strng;
    }
    public int imageresoursce(){
        return image1;
    }
}
