package com.example.burn;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/* @Entity(tableName = "food_table")
public class foodnote {
    //@PrimaryKey(autoGenerate = true)
    public String fooditems;
    @PrimaryKey(autoGenerate = true)
    public int calories;

    public int track;

    public void setTrack(int track) {
        this.track = track;
    }

    public String getFooditems() {
        return fooditems;
    }

    public int getCalories() {
        return calories;
    }

} */

