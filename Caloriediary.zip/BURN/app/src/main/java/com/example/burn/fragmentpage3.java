package com.example.burn;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
 
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class fragmentpage3 extends Fragment implements View.OnClickListener {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup root=(ViewGroup) inflater.inflate(R.layout.fragment3,container,false);
        return root;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        FloatingActionButton newBlockButton = (FloatingActionButton) getActivity().findViewById(
                R.id.floating_button);
        newBlockButton.setOnClickListener((View.OnClickListener) this);
    }



    @Override
    public void onClick(View view) {
        Intent intent = new Intent(getActivity(), loginpage.class);
        startActivity(intent);
    }

    }

