package com.example.burn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import static com.example.burn.R.id.button_add;

public class breakfast extends AppCompatActivity {
    private RecyclerView myrecycler;
    private RecyclerView.Adapter myadapter;
    private RecyclerView.LayoutManager mylayout;
    private ImageButton plus;
    private EditText add_text;
    private SearchView mysearch;
    //private foodviehmodel foodviehmodel;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breakfast);
        final ArrayList<example_item> exampleList = new ArrayList<>();


        exampleList.add(new example_item(R.drawable.ic_action_name,"Apple"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Orange"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Idli"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Dosa"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Poha"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Cereal"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Toast"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Bread"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Milk"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Banana"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Milkshake"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Peanut Butter"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Pesarattu"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Poached Egg"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Popcorn cereal"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Avacado"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Bacon"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Berries"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Burrito"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Coffee"));
        exampleList.add(new example_item(R.drawable.ic_action_name,"Omlette"));

        plus = findViewById(button_add);
        add_text = (EditText) findViewById(R.id.breakedit);
        mysearch = (SearchView) findViewById(R.id.search1);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = add_text.getText().toString();
                additem(name);
            }

            private void additem(String name) {
                exampleList.add(new example_item(R.drawable.ic_action_name,name));
            }
        });


    }


}
