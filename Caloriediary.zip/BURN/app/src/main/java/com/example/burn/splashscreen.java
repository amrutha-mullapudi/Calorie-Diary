package com.example.burn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class splashscreen extends AppCompatActivity {
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);
        configureImageView();
        configureImageView1();
        configurewater2();

        txt = (TextView) findViewById(R.id.welcome);
        Intent intent = getIntent();
        String username = intent.getStringExtra("admin");
        txt.setText("Welcome "+username);
    }

    private void configurewater2() {
        ImageView food1= (ImageView) findViewById(R.id.water1);
        food1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(splashscreen.this,circularprogress.class));
            }
        });
    }

    private void configureImageView1() {
        ImageView food1= (ImageView) findViewById(R.id.food1);
        food1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(splashscreen.this,foodblog.class));
            }
        });
    }

    private void configureImageView() {
        ImageView bmi1 = (ImageView) findViewById(R.id.bmi1);
        bmi1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(splashscreen.this,bmi.class));
            }
        });
    }


}