package com.example.burn;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/*public class adapter extends RecyclerView.Adapter {

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}


    /*<adapter.viewholder> {
    private ArrayList<example_item> myExampleList;

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.breakfast,parent,false);
        viewholder viewh = new viewholder(v);
        return viewh;
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position) {
         example_item current_item = myExampleList.get(position);
         holder.imageview.setImageResource(current_item.imageresoursce());
         holder.textview.setText(current_item.stringresource());
    }

    //@Override
    //public int getItemCount() {
       return myExampleList.size() ;
    }

    public static class viewholder extends RecyclerView.ViewHolder{
        public ImageView imageview;
        public TextView textview;

        public viewholder(@NonNull View itemView) {
            super(itemView);
            imageview = (ImageView) itemView.findViewById(R.id.breakfastlayout);
            textview = (TextView ) itemView.findViewById(R.id.breakfastlaytxt);
        }
    }
    public adapter(ArrayList<example_item> exampleList){
        myExampleList=exampleList;
*/

