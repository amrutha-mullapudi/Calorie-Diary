package com.example.burn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;

import com.mikhaellopez.circularfillableloaders.CircularFillableLoaders;

public class circularprogress extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.circularprogress);

    }
}