package com.example.burn;

public class staticrvmodel {
    private int image;
    private String text;

    public staticrvmodel(int image, String text) {
        this.image = image;
        this.text = text;
    }

    public int getImage(){
        return image;
    }

    public String getText() {
        return text;
    }
}
